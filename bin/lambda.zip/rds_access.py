import psycopg2
from psycopg2.extensions import connection

import boto3
import json

from typing import Union, Sequence, Mapping


client = boto3.client('secretsmanager')

secrets = client.get_secret_value(SecretId="prod-db-main")

secrets_dict = json.loads(secrets['SecretString'])

username = secrets_dict['username']
password = secrets_dict['password']
host = secrets_dict['host']
dbname = secrets_dict['dbname']


def get_connection() -> connection:
    conn = psycopg2.connect(dbname=dbname, user=username, password=password, host=host)
    return conn


def run_query(
    sql: str,
    substitutions: Union[Sequence, Mapping] = None,
    connection: connection = None,
    read_only: bool = True,
) -> None:
    """
    For SQL statements with no return value, like INSERT
    """
    real_connection = get_connection()
    if read_only:
        real_connection.set_session(readonly=True)
    cursor = real_connection.cursor()
    cursor.execute(sql, substitutions)
    rows = cursor.fetchall()
    cursor.close()
    real_connection.commit()
    return rows


# use `latest_tranche_date` in genotypes table, parse out last 7 days
